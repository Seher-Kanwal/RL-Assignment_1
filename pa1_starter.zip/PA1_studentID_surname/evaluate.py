"""
PA1 — evaluation and figures.

    python evaluate.py

Reads the raw per-seed output that train.py wrote to results/ and produces
the three required figures in figures/:

    figures/gridworld_values_policy.png   heatmap of V* with greedy arrows
    figures/cliff_training_curves.png     SARSA vs Q-learning, mean ± std over seeds
    figures/cliff_greedy_paths.png        each algorithm's greedy path on the grid

Evaluation is GREEDY and does not learn: act on argmax Q, never epsilon.
Keep this separate from training — the specification grades that separation.
"""
from __future__ import annotations

import pathlib

import matplotlib
matplotlib.use("Agg")           # works on headless machines
import matplotlib.pyplot as plt
import numpy as np

from pa1_envs import RoomsGridWorld, CliffWalk

FIG = pathlib.Path("figures")
RAW = pathlib.Path("results")


def greedy_rollout(env, Q: np.ndarray, max_steps: int = 400):
    """Follow argmax Q from the start. Returns (undiscounted_return, path_of_states)."""
    # TODO
    raise NotImplementedError("TODO")


def plot_gridworld(V: np.ndarray, policy: np.ndarray) -> None:
    """Heatmap of V with an arrow per cell for the greedy action; walls blank."""
    # TODO
    raise NotImplementedError("TODO")


def plot_training_curves(per_seed: dict[str, list[np.ndarray]]) -> None:
    """per_seed["sarsa"] is a list of per-episode return arrays, one per seed.
    Plot mean and a ± std band for each algorithm on the same axes."""
    # TODO
    raise NotImplementedError("TODO")


def plot_greedy_paths(paths: dict[str, list[int]]) -> None:
    """Draw each algorithm's greedy path on the 5 x 10 CliffWalk grid."""
    # TODO
    raise NotImplementedError("TODO")


def main():
    FIG.mkdir(exist_ok=True)
    # TODO: load results/*.npz, call the three plotting functions
    raise NotImplementedError("TODO")


if __name__ == "__main__":
    main()
