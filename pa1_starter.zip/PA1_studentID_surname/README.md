# PA1 — <your name>, <student ID>

Fill in every section. The grader reads this file first.

## How to reproduce

The exact commands that regenerate every number in `results.json` and every figure in `figures/`.

```bash
conda activate rl2026
python train.py --config configs/pa1.yaml
python evaluate.py
```

<!-- If any figure or number needs a different command or config, list it here. -->

## Seeds

Every seed you ran, including any that failed or were excluded, and why.

| Seed | SARSA | Q-learning | Notes |
|---|---|---|---|
| 0 | | | |
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |

## Environment

Paste the output of:

```bash
python -c "import sys, numpy, gymnasium, matplotlib; \
print('python', sys.version.split()[0]); \
print('numpy', numpy.__version__); \
print('gymnasium', gymnasium.__version__); \
print('matplotlib', matplotlib.__version__)"
```

- OS:
- CPU or GPU:
- Total wall-clock time for `train.py`:

## AI coding assistants

State which tools you used and for what. "None" is a valid answer. Undisclosed use is the violation, not use itself.

<!-- e.g. "Used Claude to debug the heatmap plotting and to explain
     np.argmax tie-breaking. Wrote all update rules in agent.py myself." -->

## Notes

Anything the grader should know: a convention you interpreted differently, a result you could not explain, a deviation from the spec and the reason.
