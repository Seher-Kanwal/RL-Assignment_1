"""
PA1 — algorithms.

Fill in every function marked TODO. Keep the signatures: train.py and
evaluate.py call them as written, and the grader assumes the conventions in
the docstrings. Read PA1_SPEC.html section 2 before writing a line.

Do NOT import stable-baselines3, cleanrl, or any library that implements
these algorithms for you.
"""
from __future__ import annotations

import numpy as np

from pa1_envs import TabularEnv


# ============================================================ dynamic programming
#
# All three functions take the model env.P directly. Conventions that decide
# the graded numbers:
#   - SYNCHRONOUS sweeps: read V_k, write into a fresh V_{k+1}. Not in-place.
#   - V starts at 0 everywhere. Terminal states stay 0.
#   - A sweep is one full pass over all states; the first pass is sweep 1.
#   - argmax ties break toward the LOWEST action index. np.argmax does this.


def policy_evaluation(env: TabularEnv, policy: np.ndarray,
                      sweeps: int | None = None, theta: float = 1e-12
                      ) -> tuple[np.ndarray, int]:
    """Iterative policy evaluation.

    policy[s, a] is the probability of action a in state s.
    If `sweeps` is given, run exactly that many and stop.
    Otherwise run until max|V_{k+1} - V_k| < theta.
    Returns (V, number_of_sweeps_performed).
    """
    raise NotImplementedError("TODO")


def greedy_policy(env: TabularEnv, V: np.ndarray) -> np.ndarray:
    """Deterministic greedy policy w.r.t. V. Returns an int array of length n_states.

    Ties break toward the lowest action index.
    """
    raise NotImplementedError("TODO")


def policy_iteration(env: TabularEnv, theta: float = 1e-12
                     ) -> tuple[np.ndarray, np.ndarray, int]:
    """Policy iteration.

    Initial policy: action 0 (up) in every state.
    One round = policy evaluation to convergence + one greedy improvement.
    Count the final round, in which the policy does not change.
    Returns (V, policy, number_of_rounds).
    """
    raise NotImplementedError("TODO")


def value_iteration(env: TabularEnv, theta: float = 1e-12
                    ) -> tuple[np.ndarray, int]:
    """Value iteration, synchronous. Returns (V, number_of_sweeps)."""
    raise NotImplementedError("TODO")


# ================================================================== TD control
#
# Conventions:
#   - Q starts at 0 everywhere.
#   - epsilon-greedy: with probability epsilon choose uniformly among all
#     actions; otherwise argmax Q[s] (lowest index on ties).
#   - Training returns are UNDISCOUNTED sums of rewards per episode.
#   - Use the provided rng for every random draw so results reproduce.


def epsilon_greedy(Q: np.ndarray, s: int, epsilon: float,
                   rng: np.random.Generator) -> int:
    """Return an action for state s."""
    raise NotImplementedError("TODO")


def sarsa(env: TabularEnv, alpha: float, epsilon: float, episodes: int,
          max_steps: int, rng: np.random.Generator
          ) -> tuple[np.ndarray, list[float]]:
    """On-policy TD control.

    Returns (Q, per_episode_training_returns).
    The target uses the action actually taken next: Q[s', a'].
    """
    raise NotImplementedError("TODO")


def q_learning(env: TabularEnv, alpha: float, epsilon: float, episodes: int,
               max_steps: int, rng: np.random.Generator
               ) -> tuple[np.ndarray, list[float]]:
    """Off-policy TD control.

    Returns (Q, per_episode_training_returns).
    The target uses the best next action: max_a' Q[s', a'].
    """
    raise NotImplementedError("TODO")
