"""
PA1 — training entry point.

    python train.py                       # everything, all seeds
    python train.py --config configs/pa1.yaml

Runs the dynamic-programming computations on RoomsGridWorld and the TD
control experiments on CliffWalk, writes raw per-seed output to results/,
and fills in results.json.

The structure below is a suggestion. Rearrange it if you prefer, but keep
the three things the grader depends on: results.json in the required
format, one raw file per seed in results/, and reproducibility from the
seeds in the config.
"""
from __future__ import annotations

import argparse
import json
import pathlib

import numpy as np
import yaml

from pa1_envs import RoomsGridWorld, CliffWalk, PROBE_STATES, ACTION_NAMES
import agent


def run_dynamic_programming(cfg: dict) -> dict:
    """Return the 'gridworld' block of results.json."""
    env = RoomsGridWorld()
    probes = PROBE_STATES["gridworld"]
    theta = float(cfg["dynamic_programming"]["theta"])
    uniform = np.full((env.n_states, env.n_actions), 1.0 / env.n_actions)

    # TODO: call agent.policy_evaluation / policy_iteration / value_iteration,
    # roll out the optimal greedy policy from the start state, and assemble:
    #
    # {
    #   "V_random_10_sweeps": {"A": ..., "B": ..., "C": ..., "D": ...},
    #   "V_random_converged": {...},
    #   "V_optimal": {...},
    #   "optimal_action": {"A": "up", ...},
    #   "policy_iteration_rounds": int,
    #   "value_iteration_sweeps": int,
    #   "optimal_undiscounted_return_from_start": float,
    # }
    #
    # Round floats to 3 decimals. Use ACTION_NAMES[a] for the action strings.
    raise NotImplementedError("TODO")


def run_cliff_dp(cfg: dict) -> dict:
    """Value-iteration items for the 'cliff' block."""
    env = CliffWalk()
    probes = PROBE_STATES["cliff"]
    # TODO: V_optimal, optimal_action, value_iteration_sweeps,
    #       optimal_undiscounted_return_from_start, optimal_path_length
    raise NotImplementedError("TODO")


def run_td_control(cfg: dict, seeds: list[int], raw_dir: pathlib.Path) -> dict:
    """SARSA and Q-learning over all seeds. Returns the six reported TD items."""
    td = cfg["td_control"]
    env = CliffWalk()
    # TODO: for each seed and each algorithm:
    #   - train with agent.sarsa / agent.q_learning using np.random.default_rng(seed)
    #   - save the per-episode returns and the final Q to raw_dir / f"{algo}_seed{seed}.npz"
    #   - evaluate the final greedy policy from the start state: undiscounted
    #     return and the highest (smallest-index) row the path visits
    # Then average over seeds:
    #   sarsa_training_return, qlearning_training_return   (last `training_return_window` episodes)
    #   sarsa_greedy_return,   qlearning_greedy_return
    #   sarsa_highest_row,     qlearning_highest_row
    raise NotImplementedError("TODO")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/pa1.yaml")
    args = ap.parse_args()
    cfg = yaml.safe_load(open(args.config))

    raw_dir = pathlib.Path(cfg["output"]["raw_dir"])
    raw_dir.mkdir(exist_ok=True)

    results = {
        "gridworld": run_dynamic_programming(cfg),
        "cliff": {**run_cliff_dp(cfg),
                  **run_td_control(cfg, cfg["seeds"], raw_dir)},
    }
    out = pathlib.Path(cfg["output"]["results_json"])
    out.write_text(json.dumps(results, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
